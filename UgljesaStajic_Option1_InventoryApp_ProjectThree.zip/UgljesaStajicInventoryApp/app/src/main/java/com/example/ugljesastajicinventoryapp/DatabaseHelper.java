package com.example.ugljesastajicinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Handles the persistent SQLite database for user accounts and inventory items.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_USERS = "users";
    private static final String TABLE_INVENTORY = "inventory_items";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {

        // Stores login credentials for each local application user.
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        "user_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT UNIQUE NOT NULL, " +
                        "password TEXT NOT NULL)";

        // Stores inventory records and associates each record with its owner.
        String createInventoryTable =
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        "item_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "item_name TEXT NOT NULL, " +
                        "quantity INTEGER NOT NULL, " +
                        "location TEXT NOT NULL)";

        database.execSQL(createUsersTable);
        database.execSQL(createInventoryTable);
    }

    /**
     * Creates a new user account. A return value of -1 means the insert failed,
     * which includes attempting to use a username that already exists.
     */
    public long createUser(String username, String password) {

        SQLiteDatabase database = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        return database.insert(
                TABLE_USERS,
                null,
                values
        );
    }

    /**
     * Checks the supplied username and password and returns the matching user ID.
     * A return value of -1 means the credentials did not match a stored account.
     */
    public long authenticateUser(
            String username,
            String password
    ) {

        SQLiteDatabase database = getReadableDatabase();

        try (Cursor cursor = database.query(
                TABLE_USERS,
                new String[]{"user_id"},
                "username = ? AND password = ?",
                new String[]{username, password},
                null,
                null,
                null
        )) {

            if (cursor.moveToFirst()) {
                return cursor.getLong(
                        cursor.getColumnIndexOrThrow("user_id")
                );
            }
        }

        return -1;
    }

    /**
     * CREATE operation for the inventory table.
     */
    public long addInventoryItem(
            long userId,
            String itemName,
            int quantity,
            String location
    ) {

        SQLiteDatabase database = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("item_name", itemName);
        values.put("quantity", quantity);
        values.put("location", location);

        return database.insert(
                TABLE_INVENTORY,
                null,
                values
        );
    }

    /**
     * READ operation. Only items that belong to the logged-in user are returned.
     */
    public Cursor getInventoryItems(long userId) {

        SQLiteDatabase database = getReadableDatabase();

        return database.query(
                TABLE_INVENTORY,
                new String[]{
                        "item_id",
                        "item_name",
                        "quantity",
                        "location"
                },
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                "item_name COLLATE NOCASE ASC"
        );
    }

    /**
     * UPDATE operation. The user ID is included in the WHERE clause so one user
     * cannot update another user's inventory record.
     */
    public int updateInventoryItem(
            long itemId,
            long userId,
            String itemName,
            int quantity,
            String location
    ) {

        SQLiteDatabase database = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("item_name", itemName);
        values.put("quantity", quantity);
        values.put("location", location);

        return database.update(
                TABLE_INVENTORY,
                values,
                "item_id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(itemId),
                        String.valueOf(userId)
                }
        );
    }

    /**
     * DELETE operation. The user ID prevents deletion of another user's item.
     */
    public int deleteInventoryItem(
            long itemId,
            long userId
    ) {

        SQLiteDatabase database = getWritableDatabase();

        return database.delete(
                TABLE_INVENTORY,
                "item_id = ? AND user_id = ?",
                new String[]{
                        String.valueOf(itemId),
                        String.valueOf(userId)
                }
        );
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase database,
            int oldVersion,
            int newVersion
    ) {

        // This course project uses a simple destructive migration strategy.
        database.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_INVENTORY
        );

        database.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_USERS
        );

        onCreate(database);
    }
}
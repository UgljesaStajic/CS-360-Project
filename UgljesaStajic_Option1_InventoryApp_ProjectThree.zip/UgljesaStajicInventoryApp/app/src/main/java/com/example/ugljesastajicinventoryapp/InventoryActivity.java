package com.example.ugljesastajicinventoryapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * Displays the signed-in user's inventory and provides all four CRUD operations.
 */
public class InventoryActivity extends AppCompatActivity {

    public static final String EXTRA_USER_ID = "user_id";

    private static final String TAG = "SMS_ALERT";

    private EditText editItemName;
    private EditText editQuantity;
    private EditText editLocation;
    private TableLayout tableInventory;

    private DatabaseHelper databaseHelper;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        editLocation = findViewById(R.id.editLocation);
        tableInventory = findViewById(R.id.tableInventory);

        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        Button buttonSmsSettings = findViewById(R.id.buttonSmsSettings);
        Button buttonLogOut = findViewById(R.id.buttonLogOut);

        userId = getIntent().getLongExtra(
                EXTRA_USER_ID,
                -1
        );

        if (userId == -1) {
            Toast.makeText(
                    this,
                    R.string.missing_user,
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        databaseHelper = new DatabaseHelper(this);

        buttonAddItem.setOnClickListener(
                view -> addItem()
        );

        // Opens the SMS permission and phone-number settings screen.
        buttonSmsSettings.setOnClickListener(view -> {

            Intent intent = new Intent(
                    InventoryActivity.this,
                    SmsPermissionActivity.class
            );

            // Tell the SMS settings screen which MakerStock user is signed in.
            intent.putExtra(
                    EXTRA_USER_ID,
                    userId
            );

            startActivity(intent);
        });

        // Returns to the existing login screen and removes this screen from the stack.
        buttonLogOut.setOnClickListener(view -> {
            Intent intent = new Intent(
                    InventoryActivity.this,
                    MainActivity.class
            );

            intent.addFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP |
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
            );

            startActivity(intent);
            finish();
        });

        loadInventoryGrid();
    }

    /**
     * Validates the input form and performs the CREATE database operation.
     */
    private void addItem() {

        String itemName = editItemName.getText().toString().trim();
        String quantityText = editQuantity.getText().toString().trim();
        String location = editLocation.getText().toString().trim();

        if (itemName.isEmpty()) {
            editItemName.setError(
                    getString(R.string.error_item_name_required)
            );
            editItemName.requestFocus();
            return;
        }

        if (quantityText.isEmpty()) {
            editQuantity.setError(
                    getString(R.string.error_quantity_required)
            );
            editQuantity.requestFocus();
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException exception) {
            editQuantity.setError(
                    getString(R.string.error_quantity_invalid)
            );
            editQuantity.requestFocus();
            return;
        }

        if (quantity < 0) {
            editQuantity.setError(
                    getString(R.string.error_quantity_negative)
            );
            editQuantity.requestFocus();
            return;
        }

        if (location.isEmpty()) {
            editLocation.setError(
                    getString(R.string.error_location_required)
            );
            editLocation.requestFocus();
            return;
        }

        long itemId = databaseHelper.addInventoryItem(
                userId,
                itemName,
                quantity,
                location
        );

        if (itemId == -1) {
            Toast.makeText(
                    this,
                    R.string.item_add_failed,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        editItemName.getText().clear();
        editQuantity.getText().clear();
        editLocation.getText().clear();

        Toast.makeText(
                this,
                R.string.item_added,
                Toast.LENGTH_SHORT
        ).show();

        loadInventoryGrid();

        // A newly created item with zero quantity triggers the inventory SMS alert.
        if (quantity == 0) {
            sendAutomaticZeroStockSms(itemName);
        }
    }

    /**
     * Performs the READ operation and rebuilds the visible grid from SQLite data.
     */
    private void loadInventoryGrid() {

        // Child zero is the permanent table header. Database rows begin at child one.
        while (tableInventory.getChildCount() > 1) {
            tableInventory.removeViewAt(1);
        }

        try (Cursor cursor = databaseHelper.getInventoryItems(userId)) {

            int itemIdIndex = cursor.getColumnIndexOrThrow("item_id");
            int itemNameIndex = cursor.getColumnIndexOrThrow("item_name");
            int quantityIndex = cursor.getColumnIndexOrThrow("quantity");
            int locationIndex = cursor.getColumnIndexOrThrow("location");

            while (cursor.moveToNext()) {

                long itemId = cursor.getLong(itemIdIndex);
                String itemName = cursor.getString(itemNameIndex);
                int quantity = cursor.getInt(quantityIndex);
                String location = cursor.getString(locationIndex);

                tableInventory.addView(
                        createInventoryRow(
                                itemId,
                                itemName,
                                quantity,
                                location
                        )
                );
            }
        }
    }

    /**
     * Builds one row in the inventory grid, including Edit and Delete controls.
     */
    private TableRow createInventoryRow(
            long itemId,
            String itemName,
            int quantity,
            String location
    ) {

        TableRow row = new TableRow(this);
        int padding = dpToPx(6);

        row.setPadding(
                padding,
                padding,
                padding,
                padding
        );

        row.addView(
                createTextCell(itemName, 2f)
        );

        row.addView(
                createTextCell(
                        String.valueOf(quantity),
                        1f
                )
        );

        row.addView(
                createTextCell(location, 2f)
        );

        LinearLayout actionLayout = new LinearLayout(this);
        actionLayout.setOrientation(LinearLayout.VERTICAL);
        actionLayout.setPadding(
                dpToPx(2),
                0,
                dpToPx(2),
                0
        );

        actionLayout.setLayoutParams(
                new TableRow.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        2f
                )
        );

        Button editButton = createActionButton(
                R.string.edit,
                R.color.color_primary_dark
        );

        editButton.setOnClickListener(
                view -> showEditItemDialog(
                        itemId,
                        itemName,
                        quantity,
                        location
                )
        );

        Button deleteButton = createActionButton(
                R.string.delete,
                R.color.color_danger
        );

        LinearLayout.LayoutParams deleteParams =
                (LinearLayout.LayoutParams) deleteButton.getLayoutParams();

        deleteParams.topMargin = dpToPx(4);
        deleteButton.setLayoutParams(deleteParams);

        deleteButton.setOnClickListener(
                view -> confirmDeleteItem(
                        itemId,
                        itemName
                )
        );

        actionLayout.addView(editButton);
        actionLayout.addView(deleteButton);
        row.addView(actionLayout);

        return row;
    }

    private TextView createTextCell(
            String value,
            float weight
    ) {

        TextView textView = new TextView(this);

        textView.setText(value);
        textView.setTextSize(12f);

        textView.setTextColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_text_primary
                )
        );

        textView.setGravity(Gravity.CENTER);

        textView.setPadding(
                dpToPx(4),
                dpToPx(4),
                dpToPx(4),
                dpToPx(4)
        );

        textView.setLayoutParams(
                new TableRow.LayoutParams(
                        0,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        weight
                )
        );

        return textView;
    }

    /**
     * Creates consistently styled action buttons for each database row.
     */
    private Button createActionButton(
            int textResource,
            int colorResource
    ) {

        Button button = new Button(this);

        button.setText(textResource);
        button.setAllCaps(false);
        button.setTextSize(11f);

        button.setTextColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_white
                )
        );

        button.setBackgroundTintList(
                ColorStateList.valueOf(
                        ContextCompat.getColor(
                                this,
                                colorResource
                        )
                )
        );

        button.setLayoutParams(
                new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dpToPx(44)
                )
        );

        return button;
    }

    /**
     * Opens a populated edit dialog and performs the UPDATE operation after
     * validating the replacement values.
     */
    private void showEditItemDialog(
            long itemId,
            String currentItemName,
            int currentQuantity,
            String currentLocation
    ) {

        LinearLayout dialogLayout =
                new LinearLayout(this);

        dialogLayout.setOrientation(
                LinearLayout.VERTICAL
        );

        dialogLayout.setPadding(
                dpToPx(20),
                dpToPx(8),
                dpToPx(20),
                0
        );

        EditText itemNameInput =
                new EditText(this);

        itemNameInput.setHint(
                R.string.item_name_hint
        );

        itemNameInput.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        );

        itemNameInput.setText(
                currentItemName
        );

        itemNameInput.setSelectAllOnFocus(
                true
        );

        EditText quantityInput =
                new EditText(this);

        quantityInput.setHint(
                R.string.quantity_hint
        );

        quantityInput.setInputType(
                InputType.TYPE_CLASS_NUMBER
        );

        quantityInput.setText(
                String.valueOf(currentQuantity)
        );

        quantityInput.setSelectAllOnFocus(
                true
        );

        EditText locationInput =
                new EditText(this);

        locationInput.setHint(
                R.string.location_hint
        );

        locationInput.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        );

        locationInput.setText(
                currentLocation
        );

        locationInput.setSelectAllOnFocus(
                true
        );

        dialogLayout.addView(
                itemNameInput
        );

        dialogLayout.addView(
                quantityInput
        );

        dialogLayout.addView(
                locationInput
        );

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle(
                                R.string.edit_inventory_item
                        )
                        .setView(
                                dialogLayout
                        )
                        .setPositiveButton(
                                R.string.update_item,
                                null
                        )
                        .setNegativeButton(
                                R.string.cancel,
                                null
                        )
                        .create();

        /*
         * Override the normal positive button so invalid input
         * does not automatically close the edit dialog.
         */
        dialog.setOnShowListener(
                unused -> dialog
                        .getButton(
                                AlertDialog.BUTTON_POSITIVE
                        )
                        .setOnClickListener(view -> {

                            String itemName =
                                    itemNameInput
                                            .getText()
                                            .toString()
                                            .trim();

                            String quantityText =
                                    quantityInput
                                            .getText()
                                            .toString()
                                            .trim();

                            String location =
                                    locationInput
                                            .getText()
                                            .toString()
                                            .trim();

                            if (itemName.isEmpty()) {

                                itemNameInput.setError(
                                        getString(
                                                R.string.error_item_name_required
                                        )
                                );

                                itemNameInput.requestFocus();
                                return;
                            }

                            if (quantityText.isEmpty()) {

                                quantityInput.setError(
                                        getString(
                                                R.string.error_quantity_required
                                        )
                                );

                                quantityInput.requestFocus();
                                return;
                            }

                            int quantity;

                            try {

                                quantity =
                                        Integer.parseInt(
                                                quantityText
                                        );

                            } catch (NumberFormatException exception) {

                                quantityInput.setError(
                                        getString(
                                                R.string.error_quantity_invalid
                                        )
                                );

                                quantityInput.requestFocus();
                                return;
                            }

                            if (quantity < 0) {

                                quantityInput.setError(
                                        getString(
                                                R.string.error_quantity_negative
                                        )
                                );

                                quantityInput.requestFocus();
                                return;
                            }

                            if (location.isEmpty()) {

                                locationInput.setError(
                                        getString(
                                                R.string.error_location_required
                                        )
                                );

                                locationInput.requestFocus();
                                return;
                            }

                            int updatedRows =
                                    databaseHelper.updateInventoryItem(
                                            itemId,
                                            userId,
                                            itemName,
                                            quantity,
                                            location
                                    );

                            if (updatedRows > 0) {

                                Toast.makeText(
                                        InventoryActivity.this,
                                        R.string.item_updated,
                                        Toast.LENGTH_SHORT
                                ).show();

                                loadInventoryGrid();
                                dialog.dismiss();

                                /*
                                 * An alert is sent only when an existing
                                 * nonzero item is changed to zero.
                                 */
                                if (currentQuantity != 0 &&
                                        quantity == 0) {

                                    sendAutomaticZeroStockSms(
                                            itemName
                                    );
                                }

                            } else {

                                Toast.makeText(
                                        InventoryActivity.this,
                                        R.string.item_update_failed,
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        })
        );

        dialog.show();
    }

    /**
     * Confirms destructive actions before performing the DELETE operation.
     */
    private void confirmDeleteItem(
            long itemId,
            String itemName
    ) {

        new AlertDialog.Builder(this)
                .setTitle(
                        R.string.confirm_delete_title
                )
                .setMessage(
                        getString(
                                R.string.confirm_delete_message,
                                itemName
                        )
                )
                .setPositiveButton(
                        R.string.delete,
                        (dialog, which) ->
                                deleteItem(itemId)
                )
                .setNegativeButton(
                        R.string.cancel,
                        null
                )
                .show();
    }

    private void deleteItem(
            long itemId
    ) {

        int deletedRows =
                databaseHelper.deleteInventoryItem(
                        itemId,
                        userId
                );

        if (deletedRows > 0) {

            Toast.makeText(
                    this,
                    R.string.item_deleted,
                    Toast.LENGTH_SHORT
            ).show();

            loadInventoryGrid();

        } else {

            Toast.makeText(
                    this,
                    R.string.item_delete_failed,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    /**
     * Sends the low-stock alert only when a phone number, permission, and
     * telephony support are all available. Otherwise the inventory remains usable.
     */
    private void sendAutomaticZeroStockSms(
            String itemName
    ) {

        SharedPreferences preferences =
                getSharedPreferences(
                        SmsPermissionActivity.PREFS_NAME,
                        MODE_PRIVATE
                );

        String phoneNumber = preferences.getString(
                SmsPermissionActivity.getPhoneNumberKey(userId),
                ""
        );

        if (phoneNumber == null ||
                phoneNumber.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    R.string.zero_stock_no_phone,
                    Toast.LENGTH_LONG
            ).show();

            Log.d(
                    TAG,
                    "Zero-stock SMS skipped because no phone number is saved."
            );

            return;
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    this,
                    R.string.zero_stock_no_permission,
                    Toast.LENGTH_LONG
            ).show();

            Log.d(
                    TAG,
                    "Zero-stock SMS skipped because SEND_SMS is not granted."
            );

            return;
        }

        if (!getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY
        )) {

            Toast.makeText(
                    this,
                    R.string.zero_stock_sms_unavailable,
                    Toast.LENGTH_LONG
            ).show();

            Log.d(
                    TAG,
                    "Zero-stock SMS skipped because telephony is unavailable."
            );

            return;
        }

        try {

            SmsManager smsManager =
                    getSystemService(
                            SmsManager.class
                    );

            if (smsManager == null) {

                Toast.makeText(
                        this,
                        R.string.zero_stock_sms_unavailable,
                        Toast.LENGTH_LONG
                ).show();

                Log.d(
                        TAG,
                        "Zero-stock SMS skipped because SmsManager is unavailable."
                );

                return;
            }

            String message =
                    getString(
                            R.string.zero_stock_sms_message,
                            itemName
                    );

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    R.string.zero_stock_alert_requested,
                    Toast.LENGTH_LONG
            ).show();

            Log.d(
                    TAG,
                    "Automatic zero-stock SMS request created for " +
                            itemName +
                            "."
            );

        } catch (Exception exception) {

            Toast.makeText(
                    this,
                    R.string.zero_stock_sms_failed,
                    Toast.LENGTH_LONG
            ).show();

            Log.e(
                    TAG,
                    "Automatic zero-stock SMS request failed.",
                    exception
            );
        }
    }

    private int dpToPx(
            int dp
    ) {

        return Math.round(
                dp *
                        getResources()
                                .getDisplayMetrics()
                                .density
        );
    }

    @Override
    protected void onDestroy() {

        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}
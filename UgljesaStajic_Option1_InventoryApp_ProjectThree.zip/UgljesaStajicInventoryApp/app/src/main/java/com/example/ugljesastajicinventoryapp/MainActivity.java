package com.example.ugljesastajicinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private TextView textLoginMessage;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        textLoginMessage = findViewById(R.id.textLoginMessage);

        Button buttonSignIn =
                findViewById(R.id.buttonSignIn);

        Button buttonCreateAccount =
                findViewById(R.id.buttonCreateAccount);

        databaseHelper = new DatabaseHelper(this);

        buttonSignIn.setOnClickListener(
                view -> signIn()
        );

        buttonCreateAccount.setOnClickListener(
                view -> createAccount()
        );
    }

    @Override
    protected void onResume() {
        super.onResume();

        /*
         * Clear private information and previous errors
         * whenever the user returns to the login screen.
         */
        if (editPassword != null) {
            editPassword.getText().clear();
        }

        if (textLoginMessage != null) {
            textLoginMessage.setText("");
        }
    }

    private boolean validateInputs() {

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString().trim();

        if (username.isEmpty()) {

            editUsername.setError(
                    getString(R.string.error_username_required)
            );

            editUsername.requestFocus();
            return false;
        }

        if (password.isEmpty()) {

            editPassword.setError(
                    getString(R.string.error_password_required)
            );

            editPassword.requestFocus();
            return false;
        }

        return true;
    }

    private void signIn() {

        if (!validateInputs()) {
            return;
        }

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString().trim();

        long userId = databaseHelper.authenticateUser(
                username,
                password
        );

        if (userId == -1) {

            textLoginMessage.setText(
                    R.string.error_invalid_login
            );

            return;
        }

        openInventory(userId);
    }

    private void createAccount() {

        if (!validateInputs()) {
            return;
        }

        String username =
                editUsername.getText().toString().trim();

        String password =
                editPassword.getText().toString().trim();

        long userId = databaseHelper.createUser(
                username,
                password
        );

        if (userId == -1) {

            textLoginMessage.setText(
                    R.string.error_username_exists
            );

            return;
        }

        Toast.makeText(
                this,
                R.string.account_created,
                Toast.LENGTH_SHORT
        ).show();

        openInventory(userId);
    }

    private void openInventory(long userId) {

        Intent intent = new Intent(
                MainActivity.this,
                InventoryActivity.class
        );

        intent.putExtra(
                InventoryActivity.EXTRA_USER_ID,
                userId
        );

        startActivity(intent);
    }

    @Override
    protected void onDestroy() {

        if (databaseHelper != null) {
            databaseHelper.close();
        }

        super.onDestroy();
    }
}
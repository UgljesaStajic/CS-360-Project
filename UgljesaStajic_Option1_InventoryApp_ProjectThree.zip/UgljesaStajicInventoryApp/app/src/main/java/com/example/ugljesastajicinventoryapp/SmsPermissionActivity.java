package com.example.ugljesastajicinventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * Allows the current MakerStock user to save a personal SMS alert number
 * and optionally enable Android SMS permission.
 */
public class SmsPermissionActivity extends AppCompatActivity {

    public static final String PREFS_NAME = "sms_settings";

    private static final String PHONE_KEY_PREFIX =
            "phone_number_user_";

    private static final String TAG = "SMS_ALERT";

    private EditText editPhoneNumber;
    private TextView textSmsStatus;

    private long userId;

    /**
     * Handles the result of Android's SMS permission request.
     */
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {

                        if (isGranted) {

                            showSmsEnabledStatus();

                            Log.d(
                                    TAG,
                                    "SEND_SMS permission granted."
                            );

                            // Let the user briefly see the green success message,
                            // then automatically return to the inventory screen.
                            returnToInventoryAfterSuccess();

                        } else {

                            showDeniedStatus();

                            Log.d(
                                    TAG,
                                    "SEND_SMS permission denied."
                            );
                        }
                    }
            );

    /**
     * Creates a separate phone-number key for each MakerStock user.
     */
    public static String getPhoneNumberKey(long userId) {
        return PHONE_KEY_PREFIX + userId;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_sms_permission
        );

        userId = getIntent().getLongExtra(
                InventoryActivity.EXTRA_USER_ID,
                -1
        );

        if (userId == -1) {

            Toast.makeText(
                    this,
                    R.string.missing_user,
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        editPhoneNumber =
                findViewById(
                        R.id.editPhoneNumber
                );

        textSmsStatus =
                findViewById(
                        R.id.textSmsStatus
                );

        Button buttonAllowSms =
                findViewById(
                        R.id.buttonAllowSms
                );

        Button buttonContinueWithoutSms =
                findViewById(
                        R.id.buttonContinueWithoutSms
                );

        SharedPreferences preferences =
                getSharedPreferences(
                        PREFS_NAME,
                        MODE_PRIVATE
                );

        /*
         * Load only the phone number belonging to the currently
         * logged-in MakerStock account.
         */
        String savedPhoneNumber =
                preferences.getString(
                        getPhoneNumberKey(userId),
                        ""
                );

        editPhoneNumber.setText(
                savedPhoneNumber
        );

        buttonAllowSms.setOnClickListener(
                view -> saveNumberAndRequestPermission()
        );

        buttonContinueWithoutSms.setOnClickListener(
                view -> {

                    Log.d(
                            TAG,
                            "User continued without changing SMS settings."
                    );

                    finish();
                }
        );

        updatePermissionStatus();
    }

    /**
     * Saves the current user's phone number and requests SMS permission
     * if Android has not already granted it to MakerStock.
     */
    private void saveNumberAndRequestPermission() {

        String phoneNumber =
                editPhoneNumber
                        .getText()
                        .toString()
                        .trim();

        if (phoneNumber.isEmpty()) {

            editPhoneNumber.setError(
                    getString(
                            R.string.error_phone_required
                    )
            );

            editPhoneNumber.requestFocus();
            return;
        }

        getSharedPreferences(
                PREFS_NAME,
                MODE_PRIVATE
        )
                .edit()
                .putString(
                        getPhoneNumberKey(userId),
                        phoneNumber
                )
                .apply();

        /*
         * Android permission is application-wide.
         * If MakerStock already has SEND_SMS permission, there is no
         * reason to display Android's permission dialog again.
         */
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            showSmsEnabledStatus();

            Toast.makeText(
                    this,
                    R.string.phone_number_saved,
                    Toast.LENGTH_SHORT
            ).show();

            Log.d(
                    TAG,
                    "Phone number saved and SMS permission was already granted."
            );

            returnToInventoryAfterSuccess();

        } else {

            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS
            );
        }
    }

    /**
     * Displays the correct initial status based on both Android permission
     * and whether this particular MakerStock account has saved a phone number.
     */
    private void updatePermissionStatus() {

        SharedPreferences preferences =
                getSharedPreferences(
                        PREFS_NAME,
                        MODE_PRIVATE
                );

        String phoneNumber =
                preferences.getString(
                        getPhoneNumberKey(userId),
                        ""
                );

        boolean hasSavedPhoneNumber =
                phoneNumber != null &&
                        !phoneNumber.trim().isEmpty();

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (permissionGranted && hasSavedPhoneNumber) {

            /*
             * This account has both pieces required for alerts:
             * Android SMS permission and its own saved phone number.
             */
            showSmsEnabledStatus();

        } else if (permissionGranted) {

            /*
             * MakerStock has Android SMS permission from another session/account,
             * but this account still needs its own phone number.
             */
            showPermissionReadyStatus();

        } else {

            showNotGrantedStatus();
        }
    }

    /**
     * Green state: this account has a saved number and MakerStock
     * has Android SMS permission.
     */
    private void showSmsEnabledStatus() {

        textSmsStatus.setText(
                R.string.sms_status_granted
        );

        textSmsStatus.setBackgroundColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_success_background
                )
        );

        textSmsStatus.setTextColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_success_text
                )
        );
    }

    /**
     * Neutral/warning state: Android permission exists, but the current
     * account still needs to save its own phone number.
     */
    private void showPermissionReadyStatus() {

        textSmsStatus.setText(
                R.string.sms_status_permission_ready
        );

        textSmsStatus.setBackgroundColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_warning_background
                )
        );

        textSmsStatus.setTextColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_warning_text
                )
        );
    }

    private void showDeniedStatus() {

        textSmsStatus.setText(
                R.string.sms_status_denied
        );

        textSmsStatus.setBackgroundColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_warning_background
                )
        );

        textSmsStatus.setTextColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_warning_text
                )
        );
    }

    private void showNotGrantedStatus() {

        textSmsStatus.setText(
                R.string.sms_status_not_granted
        );

        textSmsStatus.setBackgroundColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_warning_background
                )
        );

        textSmsStatus.setTextColor(
                ContextCompat.getColor(
                        this,
                        R.color.color_warning_text
                )
        );
    }

    /**
     * Briefly keeps the success state visible before returning
     * to the InventoryActivity underneath this screen.
     */
    private void returnToInventoryAfterSuccess() {

        textSmsStatus.postDelayed(
                this::finish,
                1000
        );
    }
}